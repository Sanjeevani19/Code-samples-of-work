function allowDrop(ev) {
    ev.preventDefault();
}

function dragImage(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
    ev.dataTransfer.setData("divid", ev.target.parentNode.id);

}

function dropImage(ev) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    var node=document.getElementById(ev.target.parentNode.id);

    var parentnode=ev.dataTransfer.getData("divid");
    if(node&&parentnode&&document.getElementById(data)&&document.getElementById(ev.target.id)) {
        var child=document.getElementById(data);
        document.getElementById(parentnode).appendChild(document.getElementById(ev.target.id));
        while (node.hasChildNodes()) {
            node.removeChild(node.lastChild);
        }
        node.appendChild(child);
    }
}