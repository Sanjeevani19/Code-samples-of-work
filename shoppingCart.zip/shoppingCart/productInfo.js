var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};

var prodIdFromURL = getUrlParameter('prodId');
$(document).ready(function () {
    $.ajax({
        type: "GET",
        url: "productList.json",
        success: function (result) {
            var productDetails = result['List'].find(x => x.prodId === parseInt(prodIdFromURL));
            $('#productName').html(productDetails.caption);
            $('#productImage').html('<img src="' + productDetails.imageURL + '">');
            $('#productDescription').html(productDetails.description);
            $('#productCategory').html(productDetails.brand);
            $('#productPrice').html(productDetails.currency + ' ' + productDetails.price);
        }
    });

});