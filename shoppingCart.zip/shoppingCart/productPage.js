function goToProductPage(ID) {
    window.location.href = 'main.html?prodId=' + ID;
}

$(document).ready(function () {
    var displayResources = $('#display-resources');
    $.ajax({
        type: "GET",
        url: "productList.json",
        success: function (result) {
            var output = "<div class='content'><div class='prodcut-grid product-grid-flexbox'><div class='product-grid__wrapper'>";
            for (var i in result['List']) {
                output += "<div class='product-grid__product-wrapper'><div class='product-grid__product'><div class='product-grid__img-wrapper'>" + "<img src='" + result['List'][i].mediumImageURL + "'/>" + "</div>" +
                    "<span class='product-grid__title'>" + result['List'][i].caption + "</span>"
                    + "<span class='product-grid__price'>" + result['List'][i].price + result['List'][i].currency + "</span>" +
                    "<div class='product-grid__extend-wrapper'><div class='product-grid__extend'>" + "<span class='product-grid__btn product-grid__add-to-cart'><i class='fa fa-cart-arrow-down'></i> Add to cart</span>" +
                    "<span class='product-grid__btn product-grid__view' onclick='goToProductPage(" + result['List'][i].prodId + ")'><i class='fa fa-eye'></i>View More</span>" +
                    "</div></div></div></div>";
            }
            output += "</div></div></div>";
            displayResources.html(output);
        }
    });


});
