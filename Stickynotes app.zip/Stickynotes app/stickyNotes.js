
$(document).ready(function() {
    note = $('#stickynotes'); // get references to the 'notes' list
    addNote(); //to add one sticky note to the browser on page load
});

//  adds a new note to the 'sticky notes' list
 function addNote() {
     var cls = 'colour' + Math.ceil(Math.random() * 3); //generating random colour for ever sticky note
     // adding a new note to the end of the list
        note.append("<li><div class='" + cls + "'>" +
                     "<a class='hide add' style='left: 0px' title='New Note' >+</a>" +
                    " <a class='hide remove' title='Delete Note'>x</a>" +
                     "<textarea class='stickynote-content'/>" +
                     "</div></li>");

         // will get the new note which is just been added and binding click event handlers for removing and adding sticky notes
        var newNote = note.find('li:last');
        newNote.find('.remove').click(function() {
            if(note.find('li').length!=1)
                newNote.remove();
           });
     newNote.find('.add').click(function() {
         addNote();
     });

    // event handler to show/hide,add and remove button
       addNewNoteEvent(newNote);

     }

 function addNewNoteEvent(newNote) {
     newNote.focus(function () {
                $(this).find('a').removeClass('hide');
             }).hover(function() {
                $(this).find('a').removeClass('hide');
            }, function () {
                $(this).find('a').addClass('hide');
             });
     }